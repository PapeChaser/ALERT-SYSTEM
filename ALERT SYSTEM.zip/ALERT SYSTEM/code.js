onEvent("Nextpage", "click", function( ) {
  setScreen("screen2");
  playSound("assets/category_achievements/vibrate_success_1_up.mp3", false);
});
onEvent("Nextpage2", "click", function( ) {
  setScreen("screen3");
  playSound("assets/category_bell/bells_win_high.mp3", false);
});
onEvent("FIREDRILL", "click", function( ) {
  setScreen("screen3");
  stopSound("assets/category_bell/vibrant_game_bell_ding.mp3");
});
onEvent("nextpage3", "click", function( ) {
  setScreen("screen4");
  playSound("assets/category_bell/choose_background.mp3", false);
});
onEvent("CODEBLUE", "click", function( ) {
  setScreen("screen4");
});
stopSound("assets/category_bell/choose_background.mp3");
onEvent("backtopage3", "click", function( ) {
  setScreen("screen3");
  playSound("assets/category_app/app_button_1.mp3", false);
});
onEvent("backtopage2", "click", function( ) {
  setScreen("screen2");
  playSound("assets/category_app/app_button_1.mp3", false);
});
onEvent("Backtohome", "click", function( ) {
  setScreen("screen1");
  playSound("assets/category_app/app_button_1.mp3", false);
});
onEvent("homeforscreen3", "click", function( ) {
  setScreen("screen1");
  playSound("assets/category_app/app_button_1.mp3", false);
});
onEvent("homeforpage4", "click", function( ) {
  setScreen("screen1");
  playSound("assets/category_app/app_button_1.mp3", false);
});
onEvent("CodeRed", "click", function( ) {
  setScreen("screen5");
  playSound("assets/category_digital/ring_2.mp3", false);
});
onEvent("Home5", "click", function( ) {
  setScreen("screen1");
  playSound("assets/default.mp3", false);
});
